function a() {
  alert('b')
}
a()